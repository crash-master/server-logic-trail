<?php

/* PATH: /controllers/ */
use Kernel\{
	View,
	Model
};

class /*$name*/Controller extends \Extend\Controller{
     
}