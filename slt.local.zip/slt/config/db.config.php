<?php

return [
	'dbtype' => 'mysql',

	'host' => 'localhost',

	'user' => 'root',

	'password' => '',

	'dbname' => '',

	'charset' => 'utf8'

];
