<!DOCTYPE html>
<html lang="en">
<? vjoin('Head', ['title' => '<test page>']); ?>
<body>
	<h1>This is test</h1>
</body>
</html>