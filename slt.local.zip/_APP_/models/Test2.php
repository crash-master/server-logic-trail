<?php

/*  /models/ */

class Test2 extends \Extend\Model{

    public $table = "Test2";

    public function default_rows(){
    	return [];
    }

}
