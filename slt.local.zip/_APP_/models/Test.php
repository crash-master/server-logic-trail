<?php

/*  Automatically was generated from a template slt/templates/model.php */

class Test extends \Extend\Model{

    public $table = "Test";

    public function default_cols(){
    	return [
    		"username" => "unknown"
    	];
    }

}
