<?php

/*  /models/ */

class Users extends \Extend\Model{

    public $table = "Users";

    public function default_rows(){
    	return [];
    }

}
