<?php

function components_map(){
	component("Head", "/test-layouts/head", "\Components\MainController@main_component");
}

