<?php

/* PATH: /controllers/ */

class /*$name*/Controller extends \Extensions\Controller{
	
}