<?php

/* PATH: /models/ */

class /*$modelname*/ extends \Extensions\Model{

	public $table = "/*$tablename*/";

	public function default_rows(){
		return [];
	}

}
