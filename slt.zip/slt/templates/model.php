<?php

/* PATH: /models/ */

class /*$modelname*/ extends \Extend\Model{

    public $table = "/*$tablename*/";

    public function default_rows(){
    	return [];
    }

}
