<?php

namespace Kernel\Maker;

use \Kernel\Services\RecursiveScan;
use \Kernel\Config;
use \Kernel\CodeTemplate;

class MakerBack{
	protected static function get_default_path_to_migration_dir(){
		return SLT_APP_NAME . '/migrations';
	}

	protected static function get_path_to_migration_file($migration_class, $path_to_migration_dir){
		$path_to_migration_dir = is_null($path_to_migration_dir) ? self::get_default_path_to_migration_dir() : $path_to_migration_dir;
		$path_to_migration_dir = ($path_to_migration_dir[strlen($path_to_migration_dir) - 1] != '/') ? $path_to_migration_dir . '/' : $path_to_migration_dir;
		return $path_to_migration_dir . $migration_class . '.php';
	}

	protected static function migration($migration_method, $migration_name, $path_to_migration_dir = null, $with_model = false){
		if(Config::get() -> system -> migration != "on"){
			throw new \Exception('Migration set to off in slt/config/main.config.php');
		}

		$migration_class = $migration_name . 'Migration';

		$migration_file = self::get_path_to_migration_file($migration_class, $path_to_migration_dir);

		if(!file_exists($migration_file)){
			throw new \Exception("File '{$migration_file}' does not exists");
		}

		if(!class_exists($migration_class)){
			include_once($migration_file);
		}

		if($with_model and $migration_method == 'up'){
			CodeTemplate::create('model', ['filename' => $migration_name, 'modelname' => $migration_name, 'tablename' => $migration_name], false, SLT_APP_NAME . '/models/');
		}elseif($with_model and $migration_method == 'down'){
			$path_to_model = SLT_APP_NAME . '/models/' . $migration_name . '.php';
			$path_to_model_remove = SLT_APP_NAME . '/models/.removed.' . $migration_name . '.php';
			if(file_exists($path_to_model)){
				rename($path_to_model, $path_to_model_remove);
			}
		}

		return (new $migration_class()) -> $migration_method();
	}

	protected static function migration_all($migration_method, $path_to_migration_dir = null, $with_models = false){
		$migrations = self::migrations_list($path_to_migration_dir);
		foreach($migrations as $migration){
			self::migration($migration_method, $migration['name'], $path_to_migration_dir, $with_models);
		}

		return true;
	}

	protected static function migrations_list($path_to_migration_dir = null){
		$rs = new RecursiveScan();
		$path_to_migration_dir = is_null($path_to_migration_dir) ? self::get_default_path_to_migration_dir() : $path_to_migration_dir;
		$migrations = $rs -> get_files($path_to_migration_dir, false);
		$ret = [];
		foreach($migrations as $inx => $migration){
			if(strpos($migration, 'Migration.php') === false){
				continue;
			}
			list($migration_name) = explode('Migration.php', basename($migration));
			$ret[] = ['name' => $migration_name, 'path' => $migration];
		}

		return $ret;
	}
}