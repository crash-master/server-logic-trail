<?php

/**
 * Настройки подключения к базе данных
 */

return [
	'dbtype' => 'mysql',

	'host' => 'localhost',

	'user' => 'root',

	'password' => '',

	'dbname' => 'slt.local',

	'charset' => 'utf8'

];
