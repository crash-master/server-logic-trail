<?php

namespace Extend;

class Migration{
    
    public static function up(){}

    public static function down(){}
    
}

?>