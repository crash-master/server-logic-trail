<?php

route('Modules\\ImgsStorage\\Controllers\\ImgsStorageController@install');
route('Modules\\ImgsStorage\\Controllers\\ImgsStorageController@uninstall');

route('\Modules\ImgsStorage\Controllers\ImgsStorageController@binary_image');
