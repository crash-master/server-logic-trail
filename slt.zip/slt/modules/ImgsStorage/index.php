<?php

\Kernel\Module::register('ImgsStorage');