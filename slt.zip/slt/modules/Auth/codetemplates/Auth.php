<?php

namespace Middleware\Kernelevents;

class Auth{
	public function signin($user_card){
		
	}

	public function signup($user){
		
	}

	public function signout($user){
		
	}
}