<?php

namespace Middleware\Modulesevents;

class Auth{
	public function signin($user_card){
		
	}

	public function signup($user){
		
	}

	public function signout($user){
		
	}
}