<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title><?= $title ?></title>
	<link rel="stylesheet" href="<?= asset_auth_path('assets/css/bootstrap.min.css') ?>">

	<script src="<?= asset_auth_path('assets/css/jquery-3.3.1.min.js') ?>"></script>
	<script src="<?= asset_auth_path('assets/css/bootstrap.min.js') ?>"></script>
</head>
<body style="background: #eee">