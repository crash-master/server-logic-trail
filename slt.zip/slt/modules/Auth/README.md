Auth module for SLT framework 
Version 0.2 beta