Auth module for SLT framework 
Version 0.1 beta