<?php

use Kernel\Module;

Module::register('Auth');