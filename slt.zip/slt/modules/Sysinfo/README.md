Sysinfo - Module for SLT framework/
Version 0.1 beta
Used for check system info about any page.
For use need added ?sysinfo to route in browser 