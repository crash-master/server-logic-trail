<?php

use Kernel\Module;

Module::register('Sysinfo');