<?php
use Kernel\Module;

Module::register('com');