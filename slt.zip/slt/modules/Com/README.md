COM - module for SLT framework.
Version 3.0
Used for control framework base components