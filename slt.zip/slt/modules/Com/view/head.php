<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Com</title>
	<link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
	<link rel="stylesheet" type="text/css" href="/<?= Kernel\Module::pathToModule('com') ?>materialize/css/materialize.min.css">
	<script type="text/javascript" src="/<?= Kernel\Module::pathToModule('com') ?>js/jquery-3.1.1.min.js"></script>
	<script type="text/javascript" src="/<?= Kernel\Module::pathToModule('com') ?>js/com.js"></script>
	<script type="text/javascript" src="/<?= Kernel\Module::pathToModule('com') ?>materialize/js/materialize.min.js"></script>
	<style>
		body{
			background: #333;
		}

		label .material-icons, .fix{
			position: relative;
			top: 6px;
			left: 5px;
		}
	</style>
</head>
<body>
	