  <nav class="teal darken-1">
    <div class="nav-wrapper">
      &#8195;<a href="/com" class="brand-logo">COM</a>
      <ul id="nav-mobile" class="right hide-on-med-and-down">
        <li><a href="/com">Dashboard</a></li>
        <li><a href="/">Go site home page</a></li>
        <li><a href="/com/about">About com</a></li>
      </ul>
    </div>
  </nav>
  <br>
        