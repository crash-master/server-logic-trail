<?php

\Kernel\Module::register('AjaxHelper');