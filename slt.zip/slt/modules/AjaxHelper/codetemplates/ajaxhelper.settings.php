<?php

function ah_controller_access_list(){
	return [];
}