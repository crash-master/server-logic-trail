<?php

function unioption(){
	return model('\Modules\UniOption\Models\UniOption');
}