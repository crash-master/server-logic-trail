<?php

\Kernel\Module::register('UniOption');