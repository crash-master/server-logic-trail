<?php

\Kernel\Module::register('ConsoleView');

