<?php

\Kernel\Module::register('ViewMaster');