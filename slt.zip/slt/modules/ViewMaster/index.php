<?php

\Kernel\Module::register('ViewMaster');

/* BUG LIST 
[] Не добавляется в карту компонентов

*/