Cool module for SLT framework
Version 0.2 beta

Auto create controller and action and generate route for new view.
Example: create _controller.hello.world.php in view folder and this module created controller for this view and renamed her to hello.world.php
Or _component.hello.world.php (module will be using app_name/controllers/components);