<?php

\Kernel\Module::register('FormHelper');