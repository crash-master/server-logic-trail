<?php

namespace Extensions;

class Migration{
    
    public function up(){}

    public function down(){}
    
}

