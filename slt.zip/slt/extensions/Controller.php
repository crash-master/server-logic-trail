<?php

namespace Extensions;

class Controller extends \Kernel\Services\SingletonPattern{

}