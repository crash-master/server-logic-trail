<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Server Logic Trail</title>
	<link rel="stylesheet" type="text/css" href="/resources/assets/css/welcome.css">
</head>
<body>
	<div class="logo-container">
		<img src="/resources/assets/imgs/stl-logo.png" class="logo">
	</div>
</body>
</html>