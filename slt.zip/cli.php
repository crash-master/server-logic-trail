<?php

$SLT_CONSOLE_MOD = true;
include('index.php');