<?php
namespace Middleware\Kernelevents;

class Router{
	public function route_not_found($route){
		
	}
}