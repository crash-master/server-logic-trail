<?php
namespace Middleware\Kernelevents;

class Controllers{
	public function call_action($controller_name, $action_name, $params, $method){

	}

	public function worked_action($controller_name, $action_name, $result_of_action){
		
	}
}