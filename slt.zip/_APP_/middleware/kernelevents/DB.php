<?php
namespace Middleware\Kernelevents;

class DB{
	public function ready_connect_to_db(){
		
	}

	public function ready_sql_query_string($sql_string){

	}

	public function response_from_db($sql_string, $response){

	}
}