<?php
namespace Middleware\Kernelevents;

class Error{
	public function error_was_found($error){
		
	}
}