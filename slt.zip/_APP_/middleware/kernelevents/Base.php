<?php
namespace Middleware\Kernelevents;

class Base{
	public function load_kernel(){
		
	}

	public function app_finished(){
		
	}
}