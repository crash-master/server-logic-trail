<?php
namespace Middleware\Kernelevents;

class Model{
	public function get_from_table($table_name, $data){
		
	}

	public function set_to_table($table_name, $data){

	}

	public function update_table($table_name, $data, $where){

	}

	public function remove_from_table($table_name, $where){
		
	}
}