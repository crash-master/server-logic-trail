<?php
namespace Middleware\Kernelevents;

class View{
	public function ready_template_for_view($template_content){
		
	}
}