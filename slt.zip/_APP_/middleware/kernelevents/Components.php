<?php
namespace Middleware\Kernelevents;

class Components{
	public function register_component($component){

	}

	public function call_component($component){
		
	}

	public function ready_component_data($component_name, $component_data){

	}
}