<?php

function components_map(){
	// component("COMPONENT_NAME", "PATH_TO_LAYOUT", "CONTROLLER")
}

