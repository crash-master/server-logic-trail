<?php
include('slt/slt.php');

use Kernel\SLT;

$slt = new SLT([
	'app_name' => '_APP_'
]);
